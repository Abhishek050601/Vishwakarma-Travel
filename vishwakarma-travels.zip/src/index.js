import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";

function TravelWebsite() {
  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-blue-600 text-white p-6 shadow-md">
        <h1 className="text-3xl font-bold">Vishwakarma Travels</h1>
        <p className="text-sm mt-1">Reliable Car Rentals & Tour Services</p>
      </header>

      <section className="p-8 grid md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-semibold mb-4">Why Choose Us?</h2>
          <ul className="list-disc ml-6 space-y-2">
            <li>Clean, well-maintained vehicles (Ertiga, Innova, etc.)</li>
            <li>Experienced, verified drivers</li>
            <li>Local, Outstation, and Customized Tours</li>
            <li>24/7 Support and Hassle-Free Booking</li>
          </ul>
        </div>
        <img
          src="https://images.unsplash.com/photo-1602407294553-6f07aa59cd5e"
          alt="Travel Vehicle"
          className="w-full rounded-xl shadow-md"
        />
      </section>

      <section className="bg-gray-100 p-8">
        <h2 className="text-2xl font-semibold text-center mb-6">Our Services</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white p-4 rounded-xl shadow">
            <h3 className="text-lg font-semibold">Daily Car Rentals</h3>
            <p className="text-sm mt-2">Affordable Ertiga rentals for city and outstation travel.</p>
          </div>
          <div className="bg-white p-4 rounded-xl shadow">
            <h3 className="text-lg font-semibold">Corporate Travel</h3>
            <p className="text-sm mt-2">Trusted by companies for employee pickup/drop services.</p>
          </div>
          <div className="bg-white p-4 rounded-xl shadow">
            <h3 className="text-lg font-semibold">Tour Packages</h3>
            <p className="text-sm mt-2">Customizable packages for families and groups.</p>
          </div>
        </div>
      </section>

      <section className="p-8">
        <h2 className="text-2xl font-semibold text-center mb-4">Book Now</h2>
        <form className="max-w-xl mx-auto bg-white p-6 rounded-xl shadow space-y-4">
          <input type="text" placeholder="Your Name" className="w-full p-3 border rounded" />
          <input type="tel" placeholder="Phone Number" className="w-full p-3 border rounded" />
          <input type="text" placeholder="Pickup Location" className="w-full p-3 border rounded" />
          <input type="text" placeholder="Destination" className="w-full p-3 border rounded" />
          <input type="date" className="w-full p-3 border rounded" />
          <button className="bg-blue-600 text-white py-3 px-6 rounded-xl hover:bg-blue-700">Submit</button>
        </form>
      </section>

      <footer className="bg-blue-600 text-white p-4 text-center">
        &copy; {new Date().getFullYear()} Vishwakarma Travels. All rights reserved.
      </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<TravelWebsite />);